import React from 'react';
import SearchBar from './SearchBar';
import Cart from './Cart';

function App() {
  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Smart Cart 🛒</h1>
      <SearchBar />
      <Cart />
    </div>
  );
}

export default App;
