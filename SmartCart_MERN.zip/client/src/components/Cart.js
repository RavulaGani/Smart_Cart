import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Cart() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/cart').then(res => setCart(res.data));
  }, []);

  const total = cart.reduce((acc, item) => acc + item.price, 0);

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-2">Cart</h2>
      {cart.map(item => (
        <div key={item._id}>
          <p>{item.name} - ₹{item.price}</p>
        </div>
      ))}
      <p className="mt-2 font-semibold">Total: ₹{total}</p>
    </div>
  );
}

export default Cart;
