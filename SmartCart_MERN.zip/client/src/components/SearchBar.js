import React, { useState } from 'react';
import axios from 'axios';

function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);

  const search = async () => {
    const res = await axios.get(`http://localhost:5000/api/products?query=${query}`);
    setResults(res.data);
  };

  const addToCart = async (id) => {
    await axios.post('http://localhost:5000/api/cart', { id });
  };

  return (
    <div>
      <input className="border p-2 mr-2" placeholder="Search..." value={query} onChange={(e) => setQuery(e.target.value)} />
      <button className="bg-blue-500 text-white px-4 py-2" onClick={search}>Search</button>
      <div className="mt-4">
        {results.map(product => (
          <div key={product._id} className="border p-3 mb-2 rounded">
            <h2 className="text-xl font-semibold">{product.name} - ₹{product.price}</h2>
            <p>{product.description}</p>
            <p className="text-sm text-gray-500">From: {product.source}</p>
            <button onClick={() => addToCart(product._id)} className="mt-2 bg-green-500 text-white px-3 py-1 rounded">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SearchBar;
