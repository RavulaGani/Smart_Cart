const express = require('express');
const router = express.Router();
const CartItem = require('../models/CartItem');
const Product = require('../models/Product');

router.get('/', async (req, res) => {
  const items = await CartItem.find().populate('productId');
  res.json(items.map(item => item.productId));
});

router.post('/', async (req, res) => {
  const { id } = req.body;
  const item = new CartItem({ productId: id });
  await item.save();
  res.sendStatus(200);
});

module.exports = router;
