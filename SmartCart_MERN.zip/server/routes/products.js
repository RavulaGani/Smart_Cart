const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

router.get('/', async (req, res) => {
  const query = req.query.query || '';
  const results = await Product.find({ name: new RegExp(query, 'i') });
  res.json(results);
});

module.exports = router;
